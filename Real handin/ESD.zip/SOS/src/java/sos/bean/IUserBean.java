package sos.bean;

public interface IUserBean {}